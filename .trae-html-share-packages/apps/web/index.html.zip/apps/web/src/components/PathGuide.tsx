import {
  IconCheck,
  IconChevronLeft,
  IconChevronRight,
  IconClock,
  IconExit,
  IconList,
  IconPath,
  IconSignal,
  IconSkip,
  pathThemeIcon,
} from './icons';
import type { FeaturedPath, MapNode } from '../types/graph';

/** Natural Chinese tip — never concatenate edgeLabel + node label chips. */
function formatNextTip(label: string, rationale?: string | null): string {
  const why = (rationale || '').replace(/\s+/g, ' ').trim();
  const short = why.length > 32 ? `${why.slice(0, 32)}…` : why;
  if (short) return `接下来看：${label}——因为${short}`;
  return `接下来看：${label}`;
}

interface Props {
  path: FeaturedPath;
  stepIndex: number;
  currentNode: MapNode | null;
  nextNode: MapNode | null;
  completed: boolean;
  onToggleComplete: () => void;
  onPrev: () => void;
  onNext: () => void;
  onExit: () => void;
  onJump: (i: number) => void;
  onSkip?: () => void;
  tableOpen?: boolean;
  onToggleTable?: () => void;
  labelOf: (id: string) => string;
  missingEdgeAt?: boolean[];
}

export default function PathGuide({
  path,
  stepIndex,
  currentNode,
  nextNode,
  completed,
  onToggleComplete,
  onPrev,
  onNext,
  onExit,
  onJump,
  onSkip,
  tableOpen,
  onToggleTable,
  labelOf,
  missingEdgeAt,
}: Props) {
  const n = path.nodeIds.length;
  const step = path.steps?.[stepIndex];
  const nextStep = path.steps?.[stepIndex + 1];
  const difficulty = path.difficulty || null;
  const minutes = path.durationMin ?? null;
  const why = step?.rationale || path.description;
  const nextWhy = nextStep?.rationale;

  return (
    <section className="cm-path-guide cm-path-guide--card" aria-label="路径导读">
      <div className="cm-path-guide__head">
        <div className="cm-path-guide__theme-icon" aria-hidden>
          {pathThemeIcon(path.theme || path.id || path.title, 26)}
        </div>
        <div className="cm-path-guide__head-main">
          <div className="cm-path-guide__meta">
            {minutes != null ? (
              <span className="cm-path-guide__pill">
                <IconClock size={14} /> 约 {minutes} 分钟
              </span>
            ) : null}
            {difficulty ? (
              <span className="cm-path-guide__pill">
                <IconSignal size={14} /> {difficulty}
              </span>
            ) : null}
            <span className="cm-path-guide__pill">
              <IconPath size={14} /> 第 {stepIndex + 1} 步
            </span>
            {path.arc ? <span className="cm-path-guide__arc">{path.arc}</span> : null}
          </div>

          <div className="cm-path-guide__now">
            <strong className="cm-path-guide__now-title">{currentNode?.label ?? '…'}</strong>
            <p className="cm-path-guide__why">{why}</p>
            {nextNode ? (
              <p className="cm-path-guide__next">{formatNextTip(nextNode.label, nextWhy)}</p>
            ) : (
              <p className="cm-path-guide__next is-end">这条路径走完了</p>
            )}
          </div>
        </div>
      </div>

      <div className="cm-path-dots" role="tablist" aria-label="路径步骤">
        {path.nodeIds.map((_, i) => (
          <button
            key={`${path.id}-dot-${i}`}
            type="button"
            role="tab"
            aria-selected={i === stepIndex}
            className={`cm-path-dot${i === stepIndex ? ' is-active' : ''}${i < stepIndex ? ' is-done' : ''}`}
            onClick={() => onJump(i)}
            title={`第 ${i + 1} 步`}
          />
        ))}
      </div>

      <div className="cm-path-guide__controls cm-path-guide__controls--card">
        <button
          type="button"
          className="cm-icon-btn"
          onClick={onPrev}
          disabled={stepIndex <= 0}
          aria-label="上一步"
          title="上一步"
        >
          <IconChevronLeft />
        </button>
        <button
          type="button"
          className="cm-btn cm-btn--primary cm-path-guide__nextbtn cm-path-guide__nextbtn--lg"
          onClick={onNext}
          disabled={stepIndex >= n - 1}
        >
          下一步 <IconChevronRight size={16} />
        </button>
        {onSkip ? (
          <button type="button" className="cm-btn cm-btn--ghost" onClick={onSkip} title="跳过本步">
            <IconSkip size={14} /> 跳过
          </button>
        ) : null}
        {onToggleTable ? (
          <button type="button" className="cm-btn cm-btn--ghost" onClick={onToggleTable}>
            <IconList size={14} /> {tableOpen ? '收起' : '步骤'}
          </button>
        ) : null}
        <button type="button" className="cm-icon-btn" onClick={onExit} aria-label="退出" title="退出">
          <IconExit />
        </button>
        <button
          type="button"
          className={`cm-icon-btn${completed ? ' is-on' : ''}`}
          onClick={onToggleComplete}
          aria-label={completed ? '取消完成' : '完成'}
          title={completed ? '已完成' : '完成'}
        >
          <IconCheck />
        </button>
      </div>

      {tableOpen ? (
        <ol className="cm-path-table">
          {path.nodeIds.map((id, i) => {
            const st = path.steps?.[i];
            const miss = missingEdgeAt?.[i] ?? false;
            return (
              <li key={`${id}-${i}`} className={i === stepIndex ? 'is-active' : ''}>
                <button type="button" onClick={() => onJump(i)}>
                  <span className="cm-path-table__i">{i + 1}</span>
                  <span className="cm-path-table__body">
                    <strong>{labelOf(id)}</strong>
                    <em>{st?.rationale}</em>
                    {i > 0 ? (
                      miss ? (
                        <span className="cm-path-table__edge is-missing">无线</span>
                      ) : st?.edgeLabel ? (
                        <span className="cm-path-table__edge">{st.edgeLabel}</span>
                      ) : null
                    ) : null}
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
      ) : null}
    </section>
  );
}
